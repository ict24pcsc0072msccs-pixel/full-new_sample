"""
Story2Scene - Multi-Modal AI System for Generating Scene Images, 
3D Scenes, Animations, and Audio Narration from Story Text

This is the main entry point for running the Story2Scene application.
Run with: streamlit run app.py --server.port 5000
"""

import subprocess
import sys


def main():
    print("Story2Scene - Multi-Modal AI Story Visualizer")
    print("=" * 50)
    print("\nStarting Streamlit application...")
    print("Access the app at: http://localhost:5000")
    
    subprocess.run([
        sys.executable, "-m", "streamlit", "run", 
        "app.py", "--server.port", "5000"
    ])


if __name__ == "__main__":
    main()
