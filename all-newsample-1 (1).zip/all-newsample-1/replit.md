# Story2Scene - AI Story Visualizer

A multi-modal AI system that transforms story text into visual scenes, 3D renders, animations, and audio narration.

## Overview

Story2Scene is a Flask web application that uses NLP (spaCy) to parse stories, extract scenes, characters, and locations, then generates:
- 2D scene images in various art styles (realistic, anime, cartoon)
- 3D renders of scenes
- Animated GIFs
- Audio narration using text-to-speech

## Project Structure

```
/
├── flask_app.py          # Main Flask application
├── templates/            # Jinja2 HTML templates
│   ├── base.html        # Base layout template
│   └── index.html       # Main page template
├── static/
│   ├── css/style.css    # Modern dark theme styling
│   └── js/app.js        # Frontend JavaScript (AJAX, scene navigation)
├── modules/             # Core functionality modules
│   ├── nlp_scene_parser.py   # NLP story parsing with spaCy
│   ├── image_generator.py    # 2D image generation
│   ├── three_d_generator.py  # 3D render and animation generation
│   ├── audio_generator.py    # Text-to-speech narration
│   └── scene_manager.py      # Scene asset management
├── utils/               # Utility functions
│   ├── helpers.py       # Validation and text helpers
│   └── file_utils.py    # File operations
└── output/              # Generated assets storage
    ├── images/
    ├── audio/
    └── animations/
```

## Running the Application

The Flask app runs on port 5000:
```bash
python flask_app.py
```

For production deployment:
```bash
gunicorn --bind=0.0.0.0:5000 --reuse-port flask_app:app
```

## Features

1. **Story Input**: Enter or paste story text, or load a sample story
2. **NLP Analysis**: Automatically detects scenes, characters, locations, and actions
3. **Content Generation**: Generate all assets or individual scene assets
4. **Scene Navigation**: Browse through generated scenes with prev/next navigation
5. **Asset Tabs**: View 2D images, 3D renders, animations, and audio for each scene
6. **Downloads**: Download individual assets or export all as ZIP
7. **Settings**: Choose art style and narration voice

## Dependencies

- Flask & Flask-Session (web framework)
- spaCy with en_core_web_sm model (NLP)
- gTTS (text-to-speech)
- Pillow (image processing)
- NumPy & Pandas (data processing)
- gunicorn (production server)

## Session Management

The app uses Flask-Session with filesystem storage for session data. All generated assets are stored per-session to ensure user isolation.

## Recent Changes

- **Dec 2025**: Converted from Streamlit to Flask for a more customizable UI
- Added modern dark theme with gradient styling
- Implemented AJAX-based scene navigation
- Session-isolated ZIP export for multi-user support
